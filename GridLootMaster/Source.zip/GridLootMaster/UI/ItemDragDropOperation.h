#pragma once

#include "CoreMinimal.h"
#include "Blueprint/DragDropOperation.h"
#include "../ItemData.h"
#include "ItemDragDropOperation.generated.h"

UCLASS()
class GRIDLOOTMASTER_API UItemDragDropOperation : public UDragDropOperation
{
    GENERATED_BODY()
    
public:
    // 드래그 중인 아이템의 ID
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag Drop", meta = (ExposeOnSpawn = "true"))
    FName ItemID;

    // 드래그 중인 아이템의 원래 크기
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    class UItemInstance* ItemObj;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    FVector2D MouseOffset;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    class UDraggableItemWidget* OriginalWidget;

    UPROPERTY()
    class UDraggableItemWidget* DragVisual;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    bool bIsSplitDrag = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    bool bOriginalRotation = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    bool bPreviewRotation = false;

    void TogglePreviewRotation();
    static void SetActiveOperation(UItemDragDropOperation* InOperation);
    static void ClearActiveOperation(const UItemDragDropOperation* InOperation);
    static UItemDragDropOperation* GetActiveOperation();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    class UGridInventoryComponent* SourceInventory = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drag and Drop")
    int32 SourceSectionIndex = 0;

    UPROPERTY()
    class UModSlotWidget* SourceModSlot = nullptr;

    UPROPERTY()
    FName SourceEquipmentSlot = NAME_None;
};
