#include "MinimapWidget.h"
#include "MinimapTileWidget.h"
#include "Blueprint/WidgetTree.h"
#include "Components/UniformGridPanel.h"
#include "Components/UniformGridSlot.h"
#include "Components/VerticalBox.h"
#include "Components/VerticalBoxSlot.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "Engine/World.h"
#include "../GridGameMode.h"
#include "../CombatComponent.h"

void UMinimapWidget::NativeConstruct()
{
    Super::NativeConstruct();
}

void UMinimapWidget::InitMinimap(UMapManagerComponent* InMapManager)
{
    MapManager = InMapManager;
    CurrentPlayerCoord = FIntPoint(0, 0); // 시작 위치
    CurrentTargetCoord = CurrentPlayerCoord;
    CurrentPath.Empty();
    CurrentMoveProgress = 0;

    if (!WidgetTree)
    {
        WidgetTree = NewObject<UWidgetTree>(this, TEXT("WidgetTree"));
    }

    if (!MapManager) return;

    UVerticalBox* RootBox = WidgetTree->ConstructWidget<UVerticalBox>(UVerticalBox::StaticClass());
    WidgetTree->RootWidget = RootBox;

    // 맵 렌더링을 위한 패널
    MapGridPanel = WidgetTree->ConstructWidget<UUniformGridPanel>(UUniformGridPanel::StaticClass());
    MapGridPanel->SetSlotPadding(FMargin(1.0f));
    
    if (UVerticalBoxSlot* MapSlot = Cast<UVerticalBoxSlot>(RootBox->AddChild(MapGridPanel)))
    {
        MapSlot->SetHorizontalAlignment(HAlign_Center);
        MapSlot->SetVerticalAlignment(VAlign_Center);
        MapSlot->SetPadding(FMargin(20.0f));
    }

    // 전진 버튼 생성
    AdvanceButton = WidgetTree->ConstructWidget<UButton>(UButton::StaticClass());
    AdvanceButton->OnClicked.AddDynamic(this, &UMinimapWidget::OnAdvanceClicked);
    AdvanceButton->SetVisibility(ESlateVisibility::Hidden);

    AdvanceText = WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
    AdvanceText->SetText(FText::FromString(TEXT("전진 (0/3)")));
    AdvanceButton->AddChild(AdvanceText);

    if (UVerticalBoxSlot* BtnSlot = Cast<UVerticalBoxSlot>(RootBox->AddChild(AdvanceButton)))
    {
        BtnSlot->SetHorizontalAlignment(HAlign_Center);
        BtnSlot->SetPadding(FMargin(10.0f));
    }

    // 타일 위젯 생성
    TileWidgets.Empty();
    for (const FTileData& TileData : MapManager->MapGrid)
    {
        UMinimapTileWidget* TileWidget = WidgetTree->ConstructWidget<UMinimapTileWidget>(UMinimapTileWidget::StaticClass());
        TileWidget->InitTile(TileData, this);

        UUniformGridSlot* GridSlot = MapGridPanel->AddChildToUniformGrid(TileWidget, TileData.Coordinate.Y, TileData.Coordinate.X);
        GridSlot->SetHorizontalAlignment(HAlign_Fill);
        GridSlot->SetVerticalAlignment(VAlign_Fill);

        TileWidgets.Add(TileData.Coordinate, TileWidget);
    }

    // 시작 위치 표시만 수행하고, 실제 이동 이벤트는 발생시키지 않습니다.
    if (UMinimapTileWidget** StartTile = TileWidgets.Find(CurrentPlayerCoord))
    {
        (*StartTile)->SetHasPlayer(true);
    }
}

void UMinimapWidget::ResetMovement()
{
    if (UMinimapTileWidget** OldTile = TileWidgets.Find(CurrentPlayerCoord))
    {
        (*OldTile)->SetHasPlayer(false);
    }

    CurrentPlayerCoord = FIntPoint(0, 0);
    CurrentTargetCoord = CurrentPlayerCoord;
    CurrentPath.Empty();
    CurrentMoveProgress = 0;

    if (AdvanceButton)
    {
        AdvanceButton->SetVisibility(ESlateVisibility::Hidden);
    }
    UpdateAdvanceButtonText();
    UpdatePathHighlight();

    if (UMinimapTileWidget** StartTile = TileWidgets.Find(CurrentPlayerCoord))
    {
        (*StartTile)->SetHasPlayer(true);
    }
}

void UMinimapWidget::HandleTileClicked(FIntPoint ClickedCoord)
{
    AGridGameMode* GM = nullptr;
    if (UWorld* World = GetWorld())
    {
        GM = Cast<AGridGameMode>(World->GetAuthGameMode());
    }
    if (!GM || GM->RaidState != ERaidState::InRaid ||
        (GM->CombatComponent && GM->CombatComponent->bHasActiveEnemy))
    {
        return;
    }

    if (CurrentMoveProgress > 0)
    {
        // 이동 도중에는 현재 경로를 끝까지 유지합니다.
        return;
    }

    if (!MapManager || !AdvanceButton)
    {
        return;
    }

    // A* 길찾기로 경로 계산
    CurrentPath = MapManager->FindPath(CurrentPlayerCoord, ClickedCoord);
    
    if (CurrentPath.Num() > 0)
    {
        CurrentTargetCoord = ClickedCoord;
        CurrentMoveProgress = 0;
        AdvanceButton->SetVisibility(ESlateVisibility::Visible);
        UpdateAdvanceButtonText();
    }
    else
    {
        AdvanceButton->SetVisibility(ESlateVisibility::Hidden);
    }

    UpdatePathHighlight();
}

void UMinimapWidget::OnAdvanceClicked()
{
    if (CurrentPath.Num() == 0) return;

    AGridGameMode* GM = nullptr;
    if (UWorld* World = GetWorld())
    {
        GM = Cast<AGridGameMode>(World->GetAuthGameMode());
    }
    if (!GM || GM->RaidState != ERaidState::InRaid ||
        (GM->CombatComponent && GM->CombatComponent->bHasActiveEnemy))
    {
        return;
    }

    CurrentMoveProgress++;
    if (CurrentMoveProgress >= 3)
    {
        // 3턴 경과 시 다음 칸으로 이동
        CurrentMoveProgress = 0;
        if (!MovePlayerTo(CurrentPath[0])) // Path의 첫번째가 다음 칸
        {
            CurrentPath.Empty();
            CurrentTargetCoord = CurrentPlayerCoord;
            if (AdvanceButton)
            {
                AdvanceButton->SetVisibility(ESlateVisibility::Hidden);
            }
            UpdatePathHighlight();
            UpdateAdvanceButtonText();
            return;
        }
        CurrentPath.RemoveAt(0);

        if (CurrentPath.Num() == 0)
        {
            // 최종 도착
            AdvanceButton->SetVisibility(ESlateVisibility::Hidden);
        }
        UpdatePathHighlight();
    }
    
    UpdateAdvanceButtonText();
    
    // TODO: 여기서 1턴 경과 이벤트(허기 감소, 랜덤 인카운터 굴림 등) 호출
}

void UMinimapWidget::UpdateAdvanceButtonText()
{
    if (AdvanceText)
    {
        FString TextStr = FString::Printf(TEXT("전진 (%d/3)"), CurrentMoveProgress);
        AdvanceText->SetText(FText::FromString(TextStr));
    }
}

void UMinimapWidget::UpdatePathHighlight()
{
    // 모든 타일 하이라이트 초기화
    for (auto& Pair : TileWidgets)
    {
        Pair.Value->SetIsPath(false);
    }

    // 새로운 경로 하이라이트
    for (const FIntPoint& PathCoord : CurrentPath)
    {
        if (UMinimapTileWidget** FoundTile = TileWidgets.Find(PathCoord))
        {
            (*FoundTile)->SetIsPath(true);
        }
    }
}

bool UMinimapWidget::MovePlayerTo(FIntPoint NewCoord)
{
    if (!MapManager || !MapManager->CanMoveBetween(CurrentPlayerCoord, NewCoord))
    {
        return false;
    }

    // 기존 위치 플레이어 아이콘 숨김
    if (UMinimapTileWidget** OldTile = TileWidgets.Find(CurrentPlayerCoord))
    {
        (*OldTile)->SetHasPlayer(false);
    }

    CurrentPlayerCoord = NewCoord;

    // 새 위치 플레이어 아이콘 표시
    if (UMinimapTileWidget** NewTile = TileWidgets.Find(CurrentPlayerCoord))
    {
        (*NewTile)->SetHasPlayer(true);
    }

    OnPlayerMoved.Broadcast(CurrentPlayerCoord);
    return true;
}
